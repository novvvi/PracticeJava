package com.dojo;

class Main {

    public static void main(String[] args) {
        Project projectOne = new Project("novi");
        System.out.println(projectOne.elevatorPitch());
    }
}
